#!/bin/sh

if ping -q -c 1 -W 1 google.com >/dev/null; then
    echo "Network is available...... Adding access point support for Phidget\n"
else
    echo "The network is down, please connect phidget to network with internet access..."
    exit 1
fi


mkdir -p /lib/firmware/rtlwifi

# Phidget SBC boards comes with Linux 2.6 or 3.14. We must install the
# corresponding module.
if [ "$(uname -r)" = "3.6.3" ]; then
	echo " Installing rtl8188 wifi driver for Kernel 3.6.3"
	driver_version="rtl8188-3.6.3"
else
	echo " Installing rtl8188 wifi driver for Kernel 3.14"
	driver_version="rtl8188-3.14.27"
fi

# First, install the TL-WN821N driver
install -p -m 644 bin/$driver_version/8188eu.ko /lib/modules/$(uname -r)/kernel/drivers/net/wireless/
insmod /lib/modules/$(uname -r)/kernel/drivers/net/wireless/8188eu.ko
depmod -a
modprobe -v 8188eu
cp bin/$driver_version/rtl8188eufw.bin /lib/firmware/rtlwifi

# Activate debian sources
cp -f overlay/etc/apt/sources.list.d/* /etc/apt/sources.list.d

# Install dnsmasq for dhcp server and hostapd for AP
dpkg --configure -a #Just in case an error previously occured
DEBIAN_FRONTEND=noninteractive apt-get --fix-missing update
DEBIAN_FRONTEND=noninteractive apt-get -y install dnsmasq hostapd

# We don't need wpa_supplicant and it prevents hostapd to work
DEBIAN_FRONTEND=noninteractive apt-get -y remove wpasupplicant

# Install hostapd, we can not use the binary provided by debian as it
# is incompatible with the 8188. But we still need all init scripts
# so we only replace the hostapd binary.
install -p -m 744 bin/hostapd /usr/sbin/

# Copy all of our custom configuration files to the system
cp -rf overlay/* /

sync

echo "############### TL-WN821N USB DONGLE SUPPORT SUCCESSFULL ADDED ##########"
echo "############### PLEASE RESTART PHIDGET WITH DONGLE PLUGED      ##########"

exit 0
